public class Main {
    public static void main(String[] args) {
        Product p1= new Product();
        Product p2= new Product();
        Product p3= new Product();

        p1.setName ("Молоко");
        p1.setPrice (3);
        p1.setInstore (true);
        System.out.println("Информация о продукте: "  );
        p1.Print();

        p2.setName("Йогурт");
        p2.setPrice(2);
        p2.setInstore(false);
        System.out.println("Информация о продукте: " );
        p2.Print();

        p3.setName("Шоколад");
        p3.setPrice(5);
        p3.setInstore(true);
        System.out.println("Информация о продукте: " );
        p3.Print();

    }

}