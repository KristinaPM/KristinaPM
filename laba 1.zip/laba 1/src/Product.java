class Product {
    private String name;
    private int price;
    private boolean instore;

    public void setName(String name){
        this.name = name;
    }
    public void setPrice(int price) {
        this.price = price;
    }
    public void setInstore(boolean instore) {
        this.instore = instore;
    }


    public Product() {
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public boolean isInstore() {
        return instore;
    }

    public void Print() {
        System.out.println("Имя: " + name);

        System.out.println("Цена: " + price);
        if(instore){
            System.out.println("Есть в наличие");
        }else{
            System.out.println("Нет в наличие");}
        System.out.println("");
    }

}